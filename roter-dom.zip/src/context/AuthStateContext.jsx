import { createContext } from "react";

export const AuthStateContext = createContext(null)
export const WareHouseManagerData = createContext(null)