
import AppLoader from "../../../../AppLoader/AppLoader";
import { useState } from "react";
import { useAllDays } from "../../../../context/AllDaysProvider";
import { useQueryClient } from "react-query";
import DayCard from "./AllDaysPageComponent/DayCard";

export default function AllDaysPage() {
  const { allDays, daysLoading, selectedDay } = useAllDays();
  const [openDayId, setOpenDayId] = useState(null);
  const [dayname, setDayname] = useState(selectedDay);
  const queryClient = useQueryClient();

  if (daysLoading) return <AppLoader />;

  const toggleDay = (id) => {
    setOpenDayId(openDayId === id ? null : id);
    setDayname(id);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-100 to-gray-200 dark:from-gray-900 dark:to-gray-800 p-4 sm:p-6">
      <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100 mb-6 text-right">
        جميع أيام العمل
      </h1>

      <div className="space-y-5">
        {allDays.map((day) => {
          const dayData = queryClient.getQueryData(["allPageData", day.id]);
          return (
            <DayCard
              key={day.id}
              day={day}
              dayData={dayData}
              openDayId={openDayId}
              toggleDay={toggleDay}
              dayname={dayname}
            />
          );
        })}
      </div>
    </div>
  );
}
