import { FaBoxes, FaTruck } from "react-icons/fa";

export default function DayHeader({ day, openDayId, dayData, toggleDay }) {
  return (
    <button
      onClick={() => toggleDay(day.id)}
      className="w-full px-5 py-4 flex justify-between items-center text-right focus:outline-none"
    >
      <div className="flex flex-col sm:flex-row sm:justify-between w-full">
        <span className="text-lg sm:text-xl font-semibold text-gray-700 dark:text-gray-200">
          {day.id}
        </span>

        {openDayId !== day.id && (
          <div className="mt-2 sm:mt-0 text-sm sm:text-base flex space-x-3 justify-start sm:justify-end">
            <span className="px-2 py-1 rounded-lg bg-green-100 dark:bg-green-800 text-green-800 dark:text-white flex items-center">
              <FaBoxes className="ml-1" /> المليان: {dayData?.allStockDataDaysPage.available_mlian ?? ""}
            </span>
            <span className="px-2 py-1 rounded-lg bg-blue-100 dark:bg-blue-800 text-blue-800 dark:text-white flex items-center">
              <FaTruck className="ml-1" /> الفاضي: {dayData?.allStockDataDaysPage.available_fadi ?? ""}
            </span>
          </div>
        )}
      </div>
      <span className="text-gray-500 dark:text-gray-400 ml-3 text-xl">
        {openDayId === day.id ? "▲" : "▼"}
      </span>
    </button>
  );
}
