import { FaUser, FaBoxes, FaTruck, FaMoneyBillWave } from "react-icons/fa";

export default function TraderCard({ trader }) {
  return (
    <div className="bg-white dark:bg-gray-700 p-4 rounded-xl border border-gray-200 dark:border-gray-600 shadow hover:shadow-lg transition-shadow">
      <div className="flex flex-col gap-4 sm:flex-row sm:justify-between sm:space-x-4 text-gray-800 dark:text-white">

        <span className="flex items-center">
          <FaUser className="ml-1" /> الاسم: <span className="font-semibold">{trader.id}</span>
        </span>

        <span className="flex items-center">
          <FaBoxes className="ml-1" /> المليان المستلم: <span className="font-semibold">{trader.traderMlian}</span>
        </span>

        <span className="flex items-center">
          <FaTruck className="ml-1" /> الفاضي المسلم: <span className="font-semibold">{trader.traderFadi}</span>
        </span>

        <span className="flex items-center">
          <FaBoxes className="ml-1" /> باقي الحديد: <span className="font-semibold">{trader.totalHadid}</span>
        </span>

        <span className="flex items-center">
          <FaMoneyBillWave className="ml-1" /> الفلوس المدفوعة: <span className="font-semibold">{trader.traderMoney}</span>
        </span>

      </div>
    </div>
  );
}
