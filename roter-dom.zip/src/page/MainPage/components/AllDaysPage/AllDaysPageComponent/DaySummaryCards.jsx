import { FaBoxes, FaTruck, FaMoneyBillWave } from "react-icons/fa";

export default function DaySummaryCards({ traderData, isFetching }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">

      {/* مليان */}
      <div className="bg-green-50 dark:bg-green-900 p-3 rounded-xl shadow flex items-center justify-between">
        <div>
          <span className="font-semibold text-green-700 dark:text-green-200">المليان:</span>{" "}
          <span className="dark:text-white">
            {isFetching ? "جاري التحميل" : traderData.allStockDataDaysPage.available_mlian}
          </span>
        </div>
        <FaBoxes className="text-green-600 dark:text-green-400 text-2xl" />
      </div>

      {/* فاضي */}
      <div className="bg-blue-50 dark:bg-blue-900 p-3 rounded-xl shadow flex items-center justify-between">
        <div>
          <span className="font-semibold text-blue-700 dark:text-blue-200">الفاضي:</span>{" "}
          <span className="dark:text-white">
            {isFetching ? "جاري التحميل" : traderData.allStockDataDaysPage.available_fadi}
          </span>
        </div>
        <FaTruck className="text-blue-600 dark:text-blue-400 text-2xl" />
      </div>

      {/* الفلوس */}
      <div className="bg-yellow-50 dark:bg-yellow-900 p-3 rounded-xl shadow flex items-center justify-between">
        <div>
          <span className="font-semibold text-yellow-700 dark:text-yellow-200">الإجمالي:</span>{" "}
          <span className="dark:text-white">
            {isFetching ? "جاري التحميل" : traderData.allStockDataDaysPage.available_money}
          </span>
        </div>
        <FaMoneyBillWave className="text-yellow-600 dark:text-yellow-400 text-2xl" />
      </div>

    </div>
  );
}
