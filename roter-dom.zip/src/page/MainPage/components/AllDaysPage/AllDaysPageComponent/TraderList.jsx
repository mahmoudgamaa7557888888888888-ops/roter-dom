import TraderCard from "./TraderCard";

export default function TraderList({ traderData, isLoading }) {
  if (!traderData || traderData.allTradersDaysPage.length === 0 || isLoading) return null;

  return (
    <div className="mt-3 space-y-3">
      <div className="text-center">
        <span>قائمة التجار</span>
      </div>

      {traderData.allTradersDaysPage.map((trader) => (
        <TraderCard key={trader.id} trader={trader} />
      ))}
    </div>
  );
}
