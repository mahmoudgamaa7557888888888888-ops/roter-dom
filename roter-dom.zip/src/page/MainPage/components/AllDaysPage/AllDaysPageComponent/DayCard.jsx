import { getAllDayesPageData } from "../../../../../hoks/useStock";
import DayHeader from "./DayHeader";
import DaySummaryCards from "./DaySummaryCards";
import TraderList from "./TraderList";

export default function DayCard({ day, dayData, openDayId, toggleDay, dayname }) {
  const { data: traderData, isLoading, isFetching } = getAllDayesPageData(dayname);

  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg border border-gray-300 dark:border-gray-700 transition-transform transform hover:scale-[1.01]">
      
      <DayHeader
        day={day}
        openDayId={openDayId}
        dayData={dayData}
        toggleDay={toggleDay}
      />

      <div
        className={`overflow-hidden transition-all duration-500 ease-in-out
          ${openDayId === day.id ? "max-h-[2000px] opacity-100 px-5 py-4" : "max-h-0 opacity-0 px-5 py-0"}
        `}
      >
        {openDayId === day.id && (
          <div className="space-y-3 text-right">
            
            <DaySummaryCards traderData={traderData} isFetching={isFetching} />

            <TraderList traderData={traderData} isLoading={isLoading} />
          </div>
        )}
      </div>
    </div>
  );
}
