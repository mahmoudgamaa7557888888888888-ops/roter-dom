import React from "react";

export default function Section({ children }) {
  return (
    <div>
      <div className="grid grid-cols-1 sm:grid-cols-2 shadow-lg m-2 p-5 rounded-xl  bg-gray-50 dark:bg-gray-600 lg:grid-cols-3 gap-6">
        {children}
      </div>
    </div>
  );
}
